import React, { Component } from 'react';
import { Button } from '@mui/material';
export class Home extends Component {
  static displayName = Home.name;

  render() {
    return (
      <Button>Hello World</Button>
    );
  }
}
